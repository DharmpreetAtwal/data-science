#!/bin/bash

set -o pipefail -e
export PRELAUNCH_OUT="/var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001/prelaunch.out"
exec >"${PRELAUNCH_OUT}"
export PRELAUNCH_ERR="/var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001/prelaunch.err"
exec 2>"${PRELAUNCH_ERR}"
echo "Setting up env variables"
export JAVA_HOME=${JAVA_HOME:-"/etc/alternatives/jre"}
export HADOOP_COMMON_HOME=${HADOOP_COMMON_HOME:-"/usr/lib/hadoop"}
export HADOOP_HDFS_HOME=${HADOOP_HDFS_HOME:-"/usr/lib/hadoop-hdfs"}
export HADOOP_CONF_DIR=${HADOOP_CONF_DIR:-"/etc/hadoop/conf"}
export HADOOP_YARN_HOME=${HADOOP_YARN_HOME:-"/usr/lib/hadoop-yarn"}
export HADOOP_MAPRED_HOME=${HADOOP_MAPRED_HOME:-"/usr/lib/hadoop-mapreduce"}
export PATH=${PATH:-"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin"}
export HADOOP_TOKEN_FILE_LOCATION="/mnt1/yarn/usercache/hadoop/appcache/application_1735497139718_0003/container_1735497139718_0003_01_000001/container_tokens"
export CONTAINER_ID="container_1735497139718_0003_01_000001"
export NM_PORT="8041"
export NM_HOST="ip-10-0-4-111.ec2.internal"
export NM_HTTP_PORT="8042"
export LOCAL_DIRS="/mnt/yarn/usercache/hadoop/appcache/application_1735497139718_0003,/mnt1/yarn/usercache/hadoop/appcache/application_1735497139718_0003"
export LOCAL_USER_DIRS="/mnt/yarn/usercache/hadoop/,/mnt1/yarn/usercache/hadoop/"
export LOG_DIRS="/var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001"
export USER="hadoop"
export LOGNAME="hadoop"
export HOME="/home/"
export PWD="/mnt1/yarn/usercache/hadoop/appcache/application_1735497139718_0003/container_1735497139718_0003_01_000001"
export LOCALIZATION_COUNTERS="350022637,0,6,0,2111"
export JVM_PID="$$"
export NM_AUX_SERVICE_spark_shuffle=""
export SPARK_YARN_STAGING_DIR="hdfs://ip-10-0-10-232.ec2.internal:8020/user/hadoop/.sparkStaging/application_1735497139718_0003"
export SPARK_PREFER_IPV6="false"
export APP_SUBMIT_TIME_ENV="1735497369538"
export PYSPARK_PYTHON="/usr/bin/python3"
export PYTHONHASHSEED="0"
export PYTHONPATH="$PWD/pyspark.zip:$PWD/py4j-0.10.9.7-src.zip"
export APPLICATION_WEB_PROXY_BASE="/proxy/application_1735497139718_0003"
export CLASSPATH="/usr/lib/hadoop-lzo/lib/*:/usr/lib/hadoop/hadoop-aws.jar:/usr/share/aws/aws-java-sdk/*:/usr/share/aws/emr/goodies/lib/emr-spark-goodies.jar:/usr/share/aws/emr/security/conf:/usr/share/aws/emr/security/lib/*:/usr/share/aws/redshift/jdbc/RedshiftJDBC.jar:/usr/share/aws/redshift/spark-redshift/lib/*:/usr/share/aws/hmclient/lib/aws-glue-datacatalog-spark-client.jar:/usr/share/java/Hive-JSON-Serde/hive-openx-serde.jar:/usr/share/aws/sagemaker-spark-sdk/lib/sagemaker-spark-sdk.jar:/usr/share/aws/emr/s3select/lib/emr-s3-select-spark-connector.jar:/docker/usr/lib/hadoop-lzo/lib/*:/docker/usr/lib/hadoop/hadoop-aws.jar:/docker/usr/share/aws/aws-java-sdk/*:/docker/usr/share/aws/emr/goodies/lib/emr-spark-goodies.jar:/docker/usr/share/aws/emr/security/conf:/docker/usr/share/aws/emr/security/lib/*:/docker/usr/share/aws/redshift/jdbc/RedshiftJDBC.jar:/docker/usr/share/aws/redshift/spark-redshift/lib/*:/docker/usr/share/aws/hmclient/lib/aws-glue-datacatalog-spark-client.jar:/docker/usr/share/java/Hive-JSON-Serde/hive-openx-serde.jar:/docker/usr/share/aws/sagemaker-spark-sdk/lib/sagemaker-spark-sdk.jar:/docker/usr/share/aws/emr/s3select/lib/emr-s3-select-spark-connector.jar:$PWD:$PWD/__spark_conf__:$PWD/__spark_libs__/*:$PWD/__spark_conf__/__hadoop_conf__"
export SPARK_USER="hadoop"
export SPARK_PUBLIC_DNS="$(hostname -f)"
export MALLOC_ARENA_MAX="4"
echo "Setting up job resources"
ln -sf -- "/mnt/yarn/usercache/hadoop/filecache/25/df_rate_code.py" "df_rate_code.py"
ln -sf -- "/mnt/yarn/usercache/hadoop/filecache/21/pyspark.zip" "pyspark.zip"
ln -sf -- "/mnt/yarn/usercache/hadoop/filecache/23/__spark_libs__5713347198560152755.zip" "__spark_libs__"
ln -sf -- "/mnt1/yarn/usercache/hadoop/filecache/22/hudi-defaults.conf" "hudi-defaults.conf"
ln -sf -- "/mnt1/yarn/usercache/hadoop/filecache/24/__spark_conf__.zip" "__spark_conf__"
ln -sf -- "/mnt1/yarn/usercache/hadoop/filecache/26/py4j-0.10.9.7-src.zip" "py4j-0.10.9.7-src.zip"
echo "Copying debugging information"
# Creating copy of launch script
cp "launch_container.sh" "/var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001/launch_container.sh"
chmod 640 "/var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001/launch_container.sh"
# Determining directory contents
echo "ls -l:" 1>"/var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001/directory.info"
ls -l 1>>"/var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001/directory.info"
echo "find -L . -maxdepth 5 -ls:" 1>>"/var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001/directory.info"
find -L . -maxdepth 5 -ls 1>>"/var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001/directory.info"
echo "broken symlinks(find -L . -maxdepth 5 -type l -ls):" 1>>"/var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001/directory.info"
find -L . -maxdepth 5 -type l -ls 1>>"/var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001/directory.info"
echo "Launching container"
exec /bin/bash -c "LD_LIBRARY_PATH=\"/usr/lib/hadoop/lib/native:/usr/lib/hadoop-lzo/lib/native:/docker/usr/lib/hadoop/lib/native:/docker/usr/lib/hadoop-lzo/lib/native:$LD_LIBRARY_PATH\" $JAVA_HOME/bin/java -server -Djava.net.preferIPv6Addresses=false -XX:+IgnoreUnrecognizedVMOptions --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.lang.invoke=ALL-UNNAMED --add-opens=java.base/java.lang.reflect=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.base/java.net=ALL-UNNAMED --add-opens=java.base/java.nio=ALL-UNNAMED --add-opens=java.base/java.util=ALL-UNNAMED --add-opens=java.base/java.util.concurrent=ALL-UNNAMED --add-opens=java.base/java.util.concurrent.atomic=ALL-UNNAMED --add-opens=java.base/sun.nio.ch=ALL-UNNAMED --add-opens=java.base/sun.nio.cs=ALL-UNNAMED --add-opens=java.base/sun.security.action=ALL-UNNAMED --add-opens=java.base/sun.util.calendar=ALL-UNNAMED --add-opens=java.security.jgss/sun.security.krb5=ALL-UNNAMED -Djdk.reflect.useDirectMethodHandle=false -Xmx2048m -Djava.io.tmpdir=$PWD/tmp "$(jar='/usr/share/log4j-cve-2021-44228-hotpatch/jdk17/Log4jHotPatchFat.jar'; [ -f "$jar" ] && echo "-javaagent:$jar=log4jFixerVerbose=false" || echo "" )" '-XX:OnOutOfMemoryError=kill -9 %p' '-XX:+UseConcMarkSweepGC' '-XX:CMSInitiatingOccupancyFraction=70' '-XX:MaxHeapFreeRatio=70' '-XX:+CMSClassUnloadingEnabled' -Dspark.yarn.app.container.log.dir=/var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001 org.apache.spark.deploy.yarn.ApplicationMaster --class 'org.apache.spark.deploy.PythonRunner' --primary-py-file df_rate_code.py --arg '--data_source' --arg 's3://dharm-emr-taxi/build/2024-12/input/' --arg '--output_uri' --arg 's3://dharm-emr-taxi/build/2024-12/output/' --properties-file $PWD/__spark_conf__/__spark_conf__.properties --dist-cache-conf $PWD/__spark_conf__/__spark_dist_cache__.properties 1> /var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001/stdout 2> /var/log/hadoop-yarn/containers/application_1735497139718_0003/container_1735497139718_0003_01_000001/stderr"
